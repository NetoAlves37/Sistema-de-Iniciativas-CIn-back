import { describe, expect, it } from 'vitest';
import { FakeClock } from '@/shared/testing/fake-clock';
import { dadosDeTeste, PRAZOS_PADRAO, umaIniciativa } from '@/shared/testing/builders/iniciativa.builder';
import { SomenteAutorError, TransicaoInvalidaError } from './errors/iniciativas.errors';
import { Iniciativa } from './iniciativa';

const clock = (d = '2026-11-12T12:00:00Z') => new FakeClock(new Date(d));

describe('US01 — submissão no domínio', () => {
  // Particionamento: criação válida; estado inicial esperado.
  it('US01: submete e inicia em EM_ANDAMENTO, ciclo 1', () => {
    const i = Iniciativa.submeter(dadosDeTeste(), 'autor', true, clock(), PRAZOS_PADRAO);
    expect(i.status).toBe('EM_ANDAMENTO');
    expect(i.ciclo).toBe(1);
    expect(i.autorId).toBe('autor');
  });
});

describe('US05 — edição e ressubmissão', () => {
  // Particionamento de equivalência: autor × status permitido.
  it('US05: autor edita durante EM_ANDAMENTO', () => {
    const i = umaIniciativa().doAutor('ana').construir();
    i.editar(dadosDeTeste({ titulo: 'Editado' }), true, 'ana', clock());
    expect(i.dados.titulo).toBe('Editado');
  });
  it('US05: usuário diferente não edita', () => {
    const i = umaIniciativa().doAutor('ana').construir();
    expect(() => i.editar(dadosDeTeste(), true, 'bia', clock())).toThrow(SomenteAutorError);
  });
  it.each(['EM_VOTACAO','EM_ANALISE','APROVADA','REPROVADA'] as const)(
    'US05: edição bloqueada no status %s', status => {
      const i = umaIniciativa().doAutor('ana').noStatus(status).construir();
      expect(() => i.editar(dadosDeTeste(), true, 'ana', clock())).toThrow(TransicaoInvalidaError);
    });
  it('US05: autor ressubmete reprovada, incrementa ciclo e reabre refinamento', () => {
    const i = umaIniciativa().doAutor('ana').reprovada().noCiclo(2).construir();
    i.ressubmeter(dadosDeTeste({ titulo: 'Revisada' }), true, 'ana', clock(), PRAZOS_PADRAO);
    expect(i.status).toBe('EM_ANDAMENTO');
    expect(i.ciclo).toBe(3);
    expect(i.dados.titulo).toBe('Revisada');
  });
  it('US05: ressubmissão sem alterações de conteúdo também é permitida', () => {
    const dados = dadosDeTeste();
    const i = umaIniciativa().doAutor('ana').reprovada().construir();
    i.ressubmeter(dados, true, 'ana', clock(), PRAZOS_PADRAO);
    expect(i.ciclo).toBe(2);
  });
  it('US05: usuário diferente não ressubmete', () => {
    const i = umaIniciativa().doAutor('ana').reprovada().construir();
    expect(() => i.ressubmeter(dadosDeTeste(), true, 'bia', clock(), PRAZOS_PADRAO)).toThrow(SomenteAutorError);
  });
  it.each(['EM_ANDAMENTO','EM_VOTACAO','EM_ANALISE','APROVADA'] as const)(
    'US05: ressubmissão bloqueada em %s', status => {
      const i = umaIniciativa().doAutor('ana').noStatus(status).construir();
      expect(() => i.ressubmeter(dadosDeTeste(), true, 'ana', clock(), PRAZOS_PADRAO)).toThrow(TransicaoInvalidaError);
    });
});
