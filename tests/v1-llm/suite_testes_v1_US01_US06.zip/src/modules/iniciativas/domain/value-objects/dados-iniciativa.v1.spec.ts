import { describe, expect, it } from 'vitest';
import { DadosIniciativa, LIMITES } from './dados-iniciativa';
import { dadosValidos } from '@/shared/testing/builders/iniciativa.builder';

describe('US01 — validação dos dados da iniciativa', () => {
  // Particionamento de equivalência: conjunto de dados válido.
  it('US01-01: aceita uma iniciativa completa', () => {
    expect(() => DadosIniciativa.criar(dadosValidos())).not.toThrow();
  });

  // Particionamento: tipo fora do conjunto permitido.
  it('US01-02: rejeita tipo inválido', () => {
    expect(() => DadosIniciativa.criar(dadosValidos({ tipo: 'INVALIDO' }))).toThrow();
  });

  // Particionamento: campo obrigatório ausente/vazio.
  it.each(['titulo', 'resumo', 'detalhe', 'espaco', 'organizadores'] as const)(
    'US01: rejeita %s vazio',
    (campo) => expect(() => DadosIniciativa.criar(dadosValidos({ [campo]: '  ' }))).toThrow(),
  );

  // Valores-limite: máximo permitido e primeiro valor acima do máximo.
  it.each([
    ['titulo', LIMITES.titulo], ['resumo', LIMITES.resumo],
    ['detalhe', LIMITES.detalhe], ['espaco', LIMITES.espaco],
    ['organizadores', LIMITES.organizadores],
  ] as const)('US01: aceita %s no limite %i', (campo, limite) => {
    expect(() => DadosIniciativa.criar(dadosValidos({ [campo]: 'x'.repeat(limite) }))).not.toThrow();
  });
  it.each([
    ['titulo', LIMITES.titulo], ['resumo', LIMITES.resumo],
    ['detalhe', LIMITES.detalhe], ['espaco', LIMITES.espaco],
    ['organizadores', LIMITES.organizadores],
  ] as const)('US01: rejeita %s acima do limite', (campo, limite) => {
    expect(() => DadosIniciativa.criar(dadosValidos({ [campo]: 'x'.repeat(limite + 1) }))).toThrow();
  });

  // Particionamento de equivalência para datas e horários válidos/inválidos.
  it.each(['2026-02-30', '10/12/2026', 'abc'])('US01: rejeita data inválida %s', (inicio) =>
    expect(() => DadosIniciativa.criar(dadosValidos({ inicio }))).toThrow());
  it('US01: rejeita término anterior ao início', () =>
    expect(() => DadosIniciativa.criar(dadosValidos({ inicio: '2026-12-11', fim: '2026-12-10' }))).toThrow());
  it.each([['25:00','26:00'], ['09:60','10:00'], ['09:00','09:00'], ['10:00','09:00']] as const)(
    'US01: rejeita horário inválido/incoerente %s-%s', (horaInicio, horaFim) =>
      expect(() => DadosIniciativa.criar(dadosValidos({ horaInicio, horaFim }))).toThrow());
  it('US01: rejeita horário informado pela metade', () =>
    expect(() => DadosIniciativa.criar(dadosValidos({ horaInicio: '09:00', horaFim: '' }))).toThrow());

  // Particionamento de equivalência: periodicidade não reconhecida.
  it('US01: rejeita periodicidade inválida', () =>
    expect(() => DadosIniciativa.criar(dadosValidos({ periodicidade: 'SEMANAL_INVALIDA' }))).toThrow());
  it('US01: rejeita participantes não inteiro, zero ou acima do máximo', () => {
    for (const participantes of [0, -1, 1.5, 'abc', LIMITES.participantesMax + 1])
      expect(() => DadosIniciativa.criar(dadosValidos({ participantes }))).toThrow();
  });
  // Valores-limite de participantes.
  it.each([1, LIMITES.participantesMax])('US01: aceita participantes no limite %i', (participantes) =>
    expect(() => DadosIniciativa.criar(dadosValidos({ participantes }))).not.toThrow());
});
