import { describe, expect, it, vi } from 'vitest';
import { ConsultasIniciativas } from './queries/consultas-iniciativas';

describe('US03 — consultas do painel', () => {
  // Particionamento de equivalência: filtro por status válido é encaminhado à leitura.
  it('US03: lista iniciativas com filtro e paginação', async () => {
    const leitura = { listar: vi.fn().mockResolvedValue({ linhas: [], total: 0 }) };
    const consultas = new ConsultasIniciativas({
      leitura, usuarios: {} as any, sugestoes: {} as any, votos: {} as any,
      googleAgenda: {} as any, carregar: {} as any, clock: {} as any,
    } as any);
    await consultas.listar({ status:'EM_ANALISE', page:1, limit:10 } as any);
    expect(leitura.listar).toHaveBeenCalledWith(expect.objectContaining({status:'EM_ANALISE',page:1,limit:10}));
  });
  it('US03: consulta minhas iniciativas e contagem por status', async () => {
    const leitura = {
      listar: vi.fn().mockResolvedValue({linhas:[],total:0}),
      contagemPorStatus: vi.fn().mockResolvedValue({EM_ANDAMENTO:2}),
    };
    const consultas = new ConsultasIniciativas({leitura, usuarios:{} as any, sugestoes:{} as any,
      votos:{} as any, googleAgenda:{} as any, carregar:{} as any, clock:{} as any} as any);
    await expect(consultas.minhas('autor',{page:1,limit:10})).resolves.toMatchObject({contagemPorStatus:{EM_ANDAMENTO:2}});
    expect(leitura.contagemPorStatus).toHaveBeenCalledWith('autor');
  });
});
