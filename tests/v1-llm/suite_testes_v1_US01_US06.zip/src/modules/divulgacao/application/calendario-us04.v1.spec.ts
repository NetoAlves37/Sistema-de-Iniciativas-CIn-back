import { describe, expect, it, vi } from 'vitest';
import { ListarOcorrencias } from './use-cases/listar-ocorrencias';

describe('US04 — calendário', () => {
  it('US04: consulta aprovadas e gera ocorrências com link Google Agenda', async () => {
    const iniciativa = { id:'i1', titulo:'Evento', tipo:'EVENTO', inicio:'2026-12-10', fim:'2026-12-10',
      horaInicio:'09:00', horaFim:'10:00', espaco:'Auditório', organizadores:'Org', periodicidade:'EVENTO_UNICO' };
    const port = { aprovadasParaCalendario: vi.fn().mockResolvedValue([iniciativa]) };
    const resultado = await new ListarOcorrencias(port as any).executar({de:'2026-12-01',ate:'2026-12-20',usuarioId:'u'});
    expect(port.aprovadasParaCalendario).toHaveBeenCalled();
    expect(resultado[0]).toMatchObject({iniciativaId:'i1',titulo:'Evento'});
    expect(resultado[0].googleAgendaUrl).toContain('calendar.google.com');
  });
  it('US04: rejeita intervalo inválido', async () => {
    const port = { aprovadasParaCalendario: vi.fn() };
    await expect(new ListarOcorrencias(port as any).executar({de:'2026-12-20',ate:'2026-12-01',usuarioId:'u'})).rejects.toThrow();
    expect(port.aprovadasParaCalendario).not.toHaveBeenCalled();
  });
  it('US04: iniciativas não aprovadas não são obtidas pela porta de calendário', async () => {
    const port = { aprovadasParaCalendario: vi.fn().mockResolvedValue([]) };
    const resultado = await new ListarOcorrencias(port as any).executar({de:'2026-12-01',ate:'2026-12-20',usuarioId:'u'});
    expect(resultado).toEqual([]);
  });
});
