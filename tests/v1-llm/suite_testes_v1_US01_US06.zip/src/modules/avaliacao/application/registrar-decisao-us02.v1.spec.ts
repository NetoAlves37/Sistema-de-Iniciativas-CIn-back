import { describe, expect, it, vi } from 'vitest';
import { RegistrarDecisao } from './use-cases/registrar-decisao';
import { AutorNaoPodeDecidirError, TransicaoInvalidaError } from '@/modules/iniciativas/domain/errors/iniciativas.errors';

describe('US02 — registrar decisão', () => {
  const detalhe = { id: 'id', status: 'APROVADA' } as any;
  it('US02: aprova e retorna detalhe atualizado', async () => {
    const port = { registrarDecisao: vi.fn().mockResolvedValue(undefined), detalhe: vi.fn().mockResolvedValue(detalhe) };
    const uc = new RegistrarDecisao(port as any);
    await expect(uc.executar({ iniciativaId:'id', resultado:'APROVADA', decisor:{id:'comite',nome:'Comitê'} })).resolves.toEqual(detalhe);
    expect(port.registrarDecisao).toHaveBeenCalledWith({ iniciativaId:'id', resultado:'APROVADA', justificativa:null, decisorId:'comite' });
  });
  it('US02: reprova com justificativa', async () => {
    const port = { registrarDecisao: vi.fn(), detalhe: vi.fn().mockResolvedValue(detalhe) };
    await new RegistrarDecisao(port as any).executar({ iniciativaId:'id', resultado:'REPROVADA', justificativa:'Ajustar', decisor:{id:'c',nome:'C'} });
    expect(port.registrarDecisao).toHaveBeenCalledWith(expect.objectContaining({resultado:'REPROVADA', justificativa:'Ajustar'}));
  });
  it('US02: reprovação sem justificativa é inválida', async () => {
    const port = { registrarDecisao: vi.fn(), detalhe: vi.fn() };
    await expect(new RegistrarDecisao(port as any).executar({ iniciativaId:'id', resultado:'REPROVADA', decisor:{id:'c',nome:'C'} })).rejects.toThrow();
    expect(port.registrarDecisao).not.toHaveBeenCalled();
  });
  // Particionamento de equivalência: erro de regra do agregado é propagado.
  it('US02: propaga bloqueio de autor avaliando própria iniciativa', async () => {
    const port = { registrarDecisao: vi.fn().mockRejectedValue(new AutorNaoPodeDecidirError()), detalhe: vi.fn() };
    await expect(new RegistrarDecisao(port as any).executar({ iniciativaId:'id', resultado:'APROVADA', decisor:{id:'autor',nome:'A'} })).rejects.toThrow(AutorNaoPodeDecidirError);
  });
  it('US02: propaga decisão fora de EM_ANALISE', async () => {
    const port = { registrarDecisao: vi.fn().mockRejectedValue(new TransicaoInvalidaError('EM_ANDAMENTO','decidir')), detalhe: vi.fn() };
    await expect(new RegistrarDecisao(port as any).executar({ iniciativaId:'id', resultado:'APROVADA', decisor:{id:'c',nome:'C'} })).rejects.toThrow(TransicaoInvalidaError);
  });
});
