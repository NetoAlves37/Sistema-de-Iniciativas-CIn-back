import { describe, expect, it, vi } from 'vitest';
import { FakeClock } from '@/shared/testing/fake-clock';
import { ComentarIniciativa } from './use-cases/comentar-iniciativa';
import { FaseDeSugestoesEncerradaError, IniciativaNaoEncontradaError } from '../domain/errors/refinamento.errors';

describe('US06 — comentários', () => {
  const estado = { id:'i1', ciclo:1, status:'EM_ANDAMENTO', autorId:'a' };
  const montar = (status: string | null = 'EM_ANDAMENTO') => {
    const comentarios = { salvar: vi.fn(async c => ({id:'c1', ...c})) };
    const iniciativas = { obterEstado: vi.fn(async () => status ? {...estado,status} : null) };
    const autores = { mapaPorIds: vi.fn(async () => new Map([['u',{nome:'Usuário'}]])) };
    return new ComentarIniciativa(comentarios as any, iniciativas as any, autores as any, new FakeClock(new Date('2026-11-12T12:00:00Z')));
  };
  it('US06: comenta em iniciativa válida durante EM_ANDAMENTO', async () => {
    const uc = montar();
    await expect(uc.executar({ iniciativaId:'i1', autorId:'u', texto:'  Sugestão  ' })).resolves.toMatchObject({texto:'Sugestão'});
  });
  it('US06: texto vazio é rejeitado', async () =>
    expect(montar().executar({iniciativaId:'i1',autorId:'u',texto:'  '})).rejects.toThrow());
  it('US06: texto acima do limite é rejeitado', async () =>
    expect(montar().executar({iniciativaId:'i1',autorId:'u',texto:'x'.repeat(2001)})).rejects.toThrow());
  it('US06: iniciativa inexistente é rejeitada', async () =>
    expect(montar(null).executar({iniciativaId:'nao',autorId:'u',texto:'Comentário'})).rejects.toThrow(IniciativaNaoEncontradaError));
  it.each(['EM_ANALISE','EM_VOTACAO','APROVADA','REPROVADA'] as const)(
    'US06: comentários bloqueados em %s', async status =>
      expect(montar(status).executar({iniciativaId:'i1',autorId:'u',texto:'Comentário'})).rejects.toThrow(FaseDeSugestoesEncerradaError));
});
